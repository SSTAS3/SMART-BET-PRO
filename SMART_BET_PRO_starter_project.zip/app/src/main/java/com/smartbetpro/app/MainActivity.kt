package com.smartbetpro.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private var english = false
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val bg = Color.rgb(10, 18, 20)
        val panel = Color.rgb(20, 32, 32)
        val green = Color.rgb(68, 220, 139)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 26, 20, 20)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 24)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "SMART BET PRO"
            textSize = 24f
            setTextColor(green)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val lang = Button(this).apply {
            text = if (english) "Українська" else "English"
            setOnClickListener { english = !english; render() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(lang)
        content.addView(header)
        addGap(content, 14)
        content.addView(label(if (english) "FOOTBALL ANALYTICS" else "ФУТБОЛЬНА АНАЛІТИКА", green, 14f))
        addGap(content, 12)
        content.addView(card(panel, if (english) "LIVE MATCHES" else "МАТЧІ НАЖИВО",
            if (english) "Live scores and match statistics will appear here after connecting a football data provider."
            else "Рахунки наживо та статистика з'являться після підключення постачальника футбольних даних."))
        addGap(content, 12)
        content.addView(card(panel, if (english) "PREDICTION CENTRE" else "ЦЕНТР ПРОГНОЗІВ",
            if (english) "1X2 • Over/Under • Corners • Next goal"
            else "Перемога / нічия / поразка • Тотали • Кутові • Наступний гол"))
        addGap(content, 12)
        content.addView(card(panel, if (english) "MATCH ANALYSIS" else "АНАЛІЗ МАТЧУ",
            if (english) "Probability estimates will be calculated from available team and match statistics. No prediction guarantees a result."
            else "Імовірності розраховуватимуться за доступною статистикою команд і матчів. Жоден прогноз не гарантує результату."))
        addGap(content, 12)
        content.addView(card(panel, if (english) "ACCOUNT" else "ОБЛІКОВИЙ ЗАПИС",
            if (english) "Email sign-in will be added when a secure authentication service is connected."
            else "Вхід через електронну пошту буде додано після підключення захищеного сервісу авторизації."))
        addGap(content, 18)
        content.addView(TextView(this).apply {
            text = if (english) "Prototype • Live data and sign-in are not connected yet."
                   else "Прототип • Реальні дані та реєстрація ще не підключені."
            textSize = 12f
            setTextColor(Color.LTGRAY)
        })
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun label(text: String, color: Int, size: Float) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        setTypeface(null, android.graphics.Typeface.BOLD)
    }

    private fun card(color: Int, heading: String, body: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(color)
        }
        box.addView(label(heading, Color.WHITE, 17f))
        addGap(box, 8)
        box.addView(TextView(this).apply {
            text = body
            textSize = 14f
            setTextColor(Color.rgb(220, 230, 228))
        })
        return box
    }

    private fun addGap(layout: LinearLayout, height: Int) {
        layout.addView(View(this), LinearLayout.LayoutParams(1, height))
    }
}
